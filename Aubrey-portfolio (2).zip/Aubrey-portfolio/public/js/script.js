/* 
   File Name: script.js
   Student Name: Aubrey Mercado
   Student ID: 301262631
   Date: October 6, 2023
*/
document.addEventListener("DOMContentLoaded", function () {
    

   
    const button = document.querySelector(".my-button");

    if (button) {
        button.addEventListener("mouseenter", function () {
            button.style.backgroundColor = "#007bff";
        });

        button.addEventListener("mouseleave", function () {
            button.style.backgroundColor = "#333";
        });
    }
});
